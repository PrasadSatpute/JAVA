package com.example.aerospikedailysalesnewproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AerospikeDailySalesNewProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
