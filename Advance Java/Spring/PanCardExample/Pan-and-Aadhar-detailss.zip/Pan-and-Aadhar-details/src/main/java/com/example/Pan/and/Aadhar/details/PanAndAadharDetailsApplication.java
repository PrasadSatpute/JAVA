package com.example.Pan.and.Aadhar.details;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanAndAadharDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanAndAadharDetailsApplication.class, args);
	}

}
