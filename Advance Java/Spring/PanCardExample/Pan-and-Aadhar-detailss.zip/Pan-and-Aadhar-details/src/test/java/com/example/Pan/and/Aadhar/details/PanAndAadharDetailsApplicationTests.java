package com.example.Pan.and.Aadhar.details;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PanAndAadharDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
