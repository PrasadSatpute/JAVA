package com.spring.boot.security.springbootsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
